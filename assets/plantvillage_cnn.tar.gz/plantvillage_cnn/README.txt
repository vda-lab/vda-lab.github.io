Data source: PlantVillage data https://www.kaggle.com/datasets/emmarex/plantdisease/
